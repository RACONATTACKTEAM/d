#pragma once

#define HTTP_SERVER "85.204.96.125"
#define HTTP_PORT 80

#define TFTP_SERVER "85.204.96.125"
